Last Modified on 22-May-2017

Changes on 22-May-2017
Updated the following Group Policy settings -
a. Computer Configuration\Windows Settings\Security Settings\Windows Firewall with Advanced Security\Windows Firewall with Advanced Security: Inbound Rules
	Name						Program																				Protocol	Local Port
	TEJ Agent					Any																					TCP			6284

Changes on 09-May-2017
Updated the following Group Policy settings -
a. Computer Configuration\Windows Settings\Security Settings\Windows Firewall with Advanced Security\Windows Firewall with Advanced Security: Inbound Rules
	Name						Program																				Protocol	Local Port
	eAgent-Ports				Any																					TCP			24010, 24020, 50020
	SmartX Agent				C:\Program Files\SmartX Agent\SmartX.exe											Any			Any
b. Computer Configuration\Windows Settings\Security Settings\Windows Firewall with Advanced Security\Windows Firewall with Advanced Security: Windows Firewall Properties
	. Domain Profile: Firewall State - On
	. Domain Profile: Inbound Connections - Block
	. Domain Profile: Logging: Name - "%systemroot%\system32\logfiles\firewall\pfirewall.log"
	. Domain Profile: Logging: Size Limit - 4096 (KB)
	. Domain Profile: Logging: Log Dropped Packets - Yes
	. Private Profile: Logging: Name - "%systemroot%\system32\logfiles\firewall\pfirewall.log"
	. Private Profile: Logging: Size Limit - 4096 (KB)
	. Private Profile: Logging: Log Dropped Packets - Yes
	. Public Profile: Logging: Name - "%systemroot%\system32\logfiles\firewall\pfirewall.log"
	. Public Profile: Logging: Size Limit - 4096 (KB)
	. Public Profile: Logging: Log Dropped Packets - Yes

Changes on 05-May-2017
Updated the following settings on top of the default Aptra Security Group Policy
a. Computer Configuration\Windows Settings\Security Settings\Local Policies\Audit Policy
	. Audit directory service access	- Success, Failure
b. Computer Configuration\Windows Settings\Security Settings\Local Policies\Security Options
	. Domain member: Require strong (Windows 2000 or later) session key	- Enabled
	. Microsoft network server: Server SPN target name validation level	- Accept if provided by client
	. Network access: Remotely accessible registry paths - (None)
	. Network access: Remotely accessible registry paths and sub-paths - (None)
	. Network security: Configure encryption types allowed for Kerberos - RC4_HMAC_MD5,AES128_HMAC_SHA1,AES256_HMAC_SHA1,Future encryption types
	. Network security: Force logoff when logon hours expire - Enabled
	. System cryptography: Use FIPS compliant algorithms for encryption, hashing, and signing - Enabled
	. System settings: Optional subsystems - (None)
	. User Account Control: Admin Approval Mode for the Built-in Administrator account - Disabled
	. User Account Control: Run all administrators in Admin Approval Mode - Enabled
	. User Account Control: Switch to the secure desktop when prompting for elevation - Enabled
c. Computer Configuration\Windows Settings\Security Settings\Windows Firewall with Advanced Security\Windows Firewall with Advanced Security: Inbound Rules
	Name						Program																				Protocol	Local Port
	eAgent-Ports				Any																					TCP			24010, 50020
	FileXService				C:\FileX\FileXService.exe															Any			Any
	GBRU Primitives				%ProgramFiles%\NCR APTRA\PcGBRU\F_GBRDP2.exe										Any			Any
	Maximus Agent				C:\Program Files\Maximus Infoware\InfoXChange Agent\MaximusInfoXChangeClient.exe	Any			Any
	McAfee ePO Agent			Any																					TCP			8081
	MoniManager					C:\MoniManager\ATMAgent.exe															Any			Any
	Prima_V2 Agent				C:\Program Files\PRIMA_V2\PRIMA_AGENT.exe											Any			Any
	Radia Agent-Radexecd.exe	C:\Program Files\Novadigm\Radexecd.exe												Any			Any
	Radia Agent-Radstgms.exe	C:\Program Files\Novadigm\Radstgms.exe												Any			Any
	RMMAgent					C:\Program Files\HP SST\RMM Agent\jre\bin\RMMAgent.exe								Any			Any
	RMMAgentWrapper				C:\Program Files\HP SST\RMM Agent\RMMAgentWrapper.exe								Any			Any
	SDAgent-Ports				Any																					TCP			5001-5004, 24000, 50010, 60000-60014
	SDAgent-Wrapper.exe			C:\SDAgent\Wrapper.exe																Any			Any
	SNMP Ports					Any																					UDP			161-162
	SNMP Service				%windir%\system32\snmp.exe															Any			Any
	TPSWManagement				C:\Program Files\NCR\nManage\TPSD\TPSWManagement.exe								Any			Any
	TranxitAgent				C:\Program Files\ThinkPrise\TranxitAgent\TranXitAgent.exe							Any			Any
	Unified Agent WS			Any																					TCP			54321	
d. Computer Configuration\Administrative Templates\Network\Network Connections
	. Prohibits use of Internet Connection Firewall on your DNS domain network - Enabled
e. Computer Configuration\Administrative Templates\Windows Components\Credential User Interface
	. Enumerate administrator accounts on elevation - Disabled
f. Computer Configuration\Administrative Templates\Windows Components\Event Log Service\Application Log
	. Maximum log size - 32768 KB
g. Computer Configuration\Administrative Templates\Windows Components\Event Log Service\Security Log
	. Maximum log size - 81920 KB
h. Computer Configuration\Administrative Templates\Windows Components\Event Log Service\System Log
	. Maximum log size - 32768 KB
i. Computer Configuration\Administrative Templates\Windows Components\Event Log Service\Setup Log
	. Maximum log size - 32768 KB
j. Computer Configuration\Administrative Templates\Windows Components\Remote Desktop Services\Remote Desktop Session Host\Connections
	. Allow users to connect remotely using Remote Desktop Services - Disabled
k. User Configuration\Administrative Templates\Control Panel\Personalization
	. Enable screen saver - Disabled
	. Password protect the screen saver - Disabled
l. User Configuration\Administrative Templates\Windows Components\Windows Explorer
	. Remove CD burning features - Enabled
	. Remove Search button from Windows Explorer - Enabled
	. Remove Windows Explorer's default context menu - Enabled
	
M. Local Computer Policy->User Configuration -> Administrative Templates->Windows Components->Table PC Policies
	. Do not allow Inkball to run - Enable
	. Do not allow printing to Journal Note Writer - Enable
	. Do not allow snipping Tool to run - Enabled
	. Do not allow Windows Journal to be run - Enabled
	. Turn off pen feedback - Enabled
	. Turn off automatic learning - Enabled
	. Prevent Back-ESC mapping - Enabled
	. Prevent launch an application - Enabled
	. Prevent press and hold - Enabled
	. Turn off hardware buttons - Enabled
	. Disable text prediction - Enabled
	. For tablet pen input, dont show the input panel icon - Enabled 
	. For touch input, dont show the Input panel icon - Enabled
	. Include rarely used Chinese, Kanji. or Hanji charecters - Not Configured
	. Prevent Input Panel tab from appearing - Enabled
	. Switch to the Simplified Chinese(PRC) gesture - Not Configured
	. Turn off AutoComplete integration with Input Panel - Enabled
	. Turn off password security in Input panel - Enabled (High)
	. Turn off tolerant and Z- shaped scratch-out gestures - Enable (All)
	. Prevent Flicks Learning Mode - Enabled
	. Prevent Flicks - Enabled
	. Turn off Tablet PC Pen Training - Enabled
	. Turn off Tablet PC touch input - Disabled
	. Turn off Touch panning - Disabled
	
N. Local Computer Policy->Computer configuration->Administrative Templates->Windows Components-> Internet Explorer->Interbet Control Panel->Advanced Page
	. Play sounds in web pages
	. Play animations in web pages
	. Play videos in web pages
	
O. Local Computer Policy->Computer configuration->Administrative Templates->System->Removable Storage Access
	. WPD Devices: Deny read access - Enabled
	. WPD Devices: Deny write access - Enabled
